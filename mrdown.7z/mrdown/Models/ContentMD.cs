using System;

namespace mrdown.Models
{
    public class ContentMD
    {
        public string FileName { get; set; }
        public string Content { get; set; }

    }
}
