using System;

namespace mrdown.Models
{
    public class DirectoryFiles
    {
        public string FileName { get; set; }
        public Double FileSize { get; set; }

    }
}
